#include <stdio.h>

int main()
{
	int b=6;
	int c[5]; // array declaration
	b = a++; // unary op
	for(int i = 0;i<5;++i) // for loop
	{
		c[i] = i; //assignment to array position
	}
}
